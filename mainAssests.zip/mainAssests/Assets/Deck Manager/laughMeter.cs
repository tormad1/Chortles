using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using static UnityEngine.EventSystems.EventTrigger;
using System;
using UnityEngine.SceneManagement;

public class laughMeter : MonoBehaviour
{
    private static TMP_Text Laughtext;
    public static int laughValue;
    private static int oldVal;


    // Start is called before the first frame update
    void Start()
    {

        laughValue = 50;
        oldVal = laughValue;
        Laughtext = GetComponent<TMP_Text>();
        Laughtext.text = laughValue.ToString();

    }

    public static void laughChange()
    {
        Laughtext.text = laughValue.ToString();
        Laughtext.color = Color.black;

        if (laughValue>100)
        {
            laughValue = 100;
        }

        if (laughValue<=0)
        {
            Debug.Log("FUCKIN G DIEE!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            SceneManager.LoadScene("LoseSplashScreen");
            roundManager.EndRound();

        }
    }

    // Update is called once per frame
    void Update()
    {
    }
}
