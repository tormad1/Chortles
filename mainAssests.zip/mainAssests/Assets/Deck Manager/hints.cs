using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TMPro;
using Unity.Mathematics;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.EventSystems.EventTrigger;
using UnityEngine.UIElements;
using UnityEngine.XR;
using Unity.Collections.LowLevel.Unsafe;

public class hints : MonoBehaviour
{
    public static List<string> HintList = new List<string>();
    private static TMP_Text hintText;
    // Start is called before the first frame update
    void Start()
    {
        hintText = GetComponent<TMP_Text>();

        HintList = new List<string>()
        {
            new string("Type Match: Dark > Slapstick > Dry > Dark."),
            new string("Save Energy: Keep energy for big cards."),
            new string("Draw Smart: Keep your hand balanced."),
            new string("Practice: Learn from each round."),
            new string("Dont Die: You will lose when your laugh meter equals 0")

        };
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public static void energyHint()
    {
        hintText.text = "Low Energy";
        Debug.Log("Low Energy");
    }

    public static void Randomhint()
    {
        hintText.text =  HintList[UnityEngine.Random.Range(0, HintList.Count)];
    }
}
