using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class scoreToPos : MonoBehaviour
{ 
    private Vector3 BaseScale;
    private Vector3 BasePos;
    private float maxPos;

    // Start is called before the first frame update
    void Start()
    {
         BaseScale = transform.localScale;
         BasePos = transform.localPosition;
         maxPos= transform.localPosition.y+ transform.localScale.y;
    }

    // Update is called once per frame
    void Update()
    {
        float scores = laughMeter.laughValue;
        transform.localPosition = new Vector3(BasePos.x, (BasePos.y +(scores / 100.0f) * (maxPos - BasePos.y)), BasePos.z);
    }

    void sclaeup()
    {



    }
}
