using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class scoreMenu : MonoBehaviour
{
    private static TMP_Text ScoreText;

    // Start is called before the first frame update
    void Start()
    {

        ScoreText = GetComponent<TMP_Text>();
        ScoreText.text = Score.scoreValue.ToString();

    }

    public static void ScoreChange()
    {
        ScoreText.text = Score.scoreValue.ToString();
        ScoreText.color = Color.black;
    }

    // Update is called once per frame
    void Update()
    {
    }
}
